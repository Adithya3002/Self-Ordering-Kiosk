<input type="number" class="inp" name="quantity1" placeholder="Enter quantity">

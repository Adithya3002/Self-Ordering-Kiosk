<html>
<head>
    <title>Admin option</title>
    <link rel="stylesheet" href="adminoption.css">
</head>
<body>
<figure>
        <a href="admin.html" class="leftarrow">
            <img src="leftarrow.png">
        </a>
    </figure>

<div class='cont'>
<form action='admin2.php' method='post' class='cont'>
    		<h2>ADMIN'S OPTIONS</h2>
        	<input class='btn1' type='submit' name='btn1' value='Total Sales'>
        	<br>
        	<br>
        	<input class='btn2' type='submit' name='btn2' value='Change Amount'>
        	<br>
        	<input class='btn3' type='submit' name='btn3' value='New Item'>
    </form>
</div>
</body>
</html>
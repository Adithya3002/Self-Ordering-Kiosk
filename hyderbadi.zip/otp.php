
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
 
<body>
<form method="post" action="phpotp.php">
<table align="center">
<tr>
<td>Name</td>
<td><input type="text" name="name" placeholder="Enter your Name"</td>
</tr>
<tr>
<td>Phone Number</td>
<td><input type="text" name="num" placeholder="Valid!with country Code"</td>
</tr>
<tr>
<td></td>
<td><input type="submit" name="login" value="sign(login)[send otp]" style="background-color: #433396; border: 0px;"</td>
</tr>
<tr>
<td>Verify OTP:</td>
<td><input type="text" name="otp" placeholder="enter received otp"</td>
</tr>
<tr>
<td></td>
<td><input type="submit" name="ver" value="verify otp" style="background-color: green; border:0px;"</td>
</tr>
</table>
</form>
</body>
</html>
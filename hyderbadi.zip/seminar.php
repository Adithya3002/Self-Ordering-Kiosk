<html>
<head>
<title>Login</title>
<link rel="stylesheet" type="text/css" href="seminar.css">
</head>
<body>

<div class="cont">
    <form action="seminar2.php" method="post" class="cont">
    <h2>LOGIN</h2>
        <input type="text" name="username" placeholder="Enter your name.." >
        <br>
        <br>
        <input type="password" name="pass" placeholder="Password..">
        <br>
        <input type="phone" name="number" placeholder="Enter your phone number">
        <br>
        <input type="gmail" name="email" placeholder="Enter your valid gmail">
        <br>
        <input class="btn" type="submit" name="login" value="login"></input>
    </form>
</div>


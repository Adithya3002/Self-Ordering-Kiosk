<html>
<head>
	<title>Cust delete</title>
</head>
<body>
	<form method="post" action="">
	<label>Enter id</label><br>
	<input type="text" name="cid">
	<input type="submit" name="btn">
	</form>
</body>
</html>
<?php
if(isset($_POST['btn']))
{
	$cid=$_POST['cid'];
	if(empty($cid))
	{
		echo "<script>alert('empty');</script>";
		echo "<script>window.location.href='custdelete.php';</script>";
	}
	else
	{
		$cn=mysqli_connect('localhost','root','','customer');
		$qry="select * from cust where cid=".$cid."";
		$rs=mysqli_query($cn,$qry);
		$rc=mysqli_num_rows($rs);
		if($rc!=0)
		{
			$qry="delete from cust where cid=".$cid."";
			$rs=mysqli_query($cn,$qry);
			if($rs)
			{
				echo "<script>alert('succesfully deleted');</script>";
				echo "<script>window.location.href='custdelete.php';</script>";
			}
		}
		else
		{
			echo "<script>alert('id does not exsist');</script>";
			echo "<script>window.location.href='custdelete.php';</script>";
		}
	}
}
?>
		

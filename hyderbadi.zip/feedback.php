<html>
<head>
	<title>Feedback</title>
</head>
<body>
	<form method="post" action="save.php">
	Name<input type="text" name="nm"><br>
	Email<input type="email" name="em"><br>
	subject<input type="text" name="sub"><br>
	Message<textarea cols="20" rows="20" name="msg"></textarea><br>
	<input type="submit" name="subb" value="submit">
	<input type="submit" name="view" value="view">
	</form>
</body>
</html>

